import 'package:flutter/material.dart';
import 'package:whatsapp/UpdatePage/update_listile.dart';

class UpdateListview extends StatefulWidget {
  const UpdateListview({super.key});

  @override
  State<UpdateListview> createState() => _UpdateListviewState();
}

class _UpdateListviewState extends State<UpdateListview> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Container(
      height: size.height*0.02,
      width: size.width*0.2,

      child: Container(
        height: size.height*1,
        width: size.width*1,
        decoration: BoxDecoration(color: Color(0xff0a131a)),
        child: ListView(
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          children: [
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),
            UpdateListile("image", "Dhruv"),

          ],
        ),
      ),
    );
  }
}

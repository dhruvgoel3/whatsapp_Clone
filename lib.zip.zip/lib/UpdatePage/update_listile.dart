import 'package:flutter/material.dart';

class UpdateListile extends StatelessWidget {
  final String image,label;

  const UpdateListile(this.image,this.label);

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return ListTile(
      leading: CircleAvatar(backgroundImage: AssetImage(image),radius: 25),
      title: Text(label,style: TextStyle(fontSize: 16,fontWeight: FontWeight.w500,color: Colors.white),),
      subtitle: Row(
        children: [
          SizedBox(width: size.height*0.02),

        ],
      ),


    );
  }
}

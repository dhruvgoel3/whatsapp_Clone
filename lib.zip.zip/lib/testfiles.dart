//
// Container(
// height: double.infinity,
// width: double.infinity,
// decoration: BoxDecoration(color: Color(0xff0a131a)),
// child: Column(
// children: [
// Padding(
// padding: const EdgeInsets.only(top: 5),
// child: Container(
// height: size.height * 0.06,
// width: size.width * 0.923,
// decoration: BoxDecoration(
// color: Color(0xff272c30),
// borderRadius: BorderRadius.circular(30)),
// child: Row(
// children: [
// Padding(
// padding: const EdgeInsets.only(left: 10),
// child: CircleAvatar(
// backgroundImage: AssetImage("assets/Ai circle.jpg"),
// radius: 19,
// ),
// ),
// SizedBox(
// width: 20,
// ),
// Text(
// "Ask meta AI or Search",
// style: TextStyle(
// fontSize: 18,
// color: Color(0xff3f4649),
// fontWeight: FontWeight.w500),
// ),
// ],
// ),
// ),